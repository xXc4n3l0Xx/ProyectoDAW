package com.proyectodaw.backend.dto;

import lombok.Data;

@Data
public class ForumThreadUpdateDTO {
    private String titulo;
}
