package com.proyectodaw.backend.dto;

import lombok.Data;

@Data
public class HiloRequest {
    private Integer idUsuario;
    private String titulo;
}
