package com.proyectodaw.backend.controller;

import com.proyectodaw.backend.dto.AuthResponseDTO;
import com.proyectodaw.backend.dto.LoginRequest;
import com.proyectodaw.backend.dto.UsuarioResponseDTO;
import com.proyectodaw.backend.model.Estado;
import com.proyectodaw.backend.model.Rol;
import com.proyectodaw.backend.model.Usuario;
import com.proyectodaw.backend.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.Optional;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    // ✅ Registro con DTO de respuesta
    @PostMapping("/registro")
    public UsuarioResponseDTO registrar(@RequestBody Usuario usuario) {
        usuario.setFechaRegistro(new Timestamp(System.currentTimeMillis()));
        usuario.setPuntuacion(0);
        usuario.setEstado(new Estado(1, "Activo"));
        usuario.setRol(new Rol(2, "usuario"));

        Usuario registrado = usuarioService.registrarUsuario(usuario);

        return construirDTO(registrado);
    }

    // ✅ Login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest login) {
        Optional<AuthResponseDTO> response = usuarioService.login(login.getCorreo(), login.getContrasena());
        return response
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciales incorrectas"));
    }

    // ✅ Actualizar y devolver DTO
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Integer id, @RequestBody Usuario datos) {
        Optional<Usuario> usuarioOpt = usuarioService.buscarPorId(id);
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            usuario.setNombre(datos.getNombre());
            usuario.setCorreo(datos.getCorreo());
            usuario.setContrasena(datos.getContrasena());
            usuario.setAvatar(datos.getAvatar());

            Usuario actualizado = usuarioService.actualizarUsuario(usuario);
            return ResponseEntity.ok(construirDTO(actualizado));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado");
    }

    // 🔧 Método auxiliar para construir el DTO
    private UsuarioResponseDTO construirDTO(Usuario u) {
        UsuarioResponseDTO dto = new UsuarioResponseDTO();
        dto.setId(u.getId());
        dto.setNombre(u.getNombre());
        dto.setCorreo(u.getCorreo());
        dto.setAvatar(u.getAvatar());
        dto.setFechaRegistro(u.getFechaRegistro().toString());
        dto.setPuntuacion(u.getPuntuacion());
        dto.setEstado(u.getEstado().getDescripcion());
        dto.setRol(u.getRol().getNombre());
        return dto;
    }
}
